function makeTable(array1, array2) {
	document.writeln("<table border=\'1\'>" );
	document.writeln("<tr>");
	for (var i = 0; i < array1.length; i++) {
		document.writeln("<th class=\"imageTitle\">" + array1[i] + "<br /><img src=\"images/" + array2[i] + "\"></th>");
	}
	document.writeln("</tr>");
	year();
}

function year() {
	var d = new Date();
	var year = d.getFullYear();
	var list = new Array();

	for (var i = 1912; i <= year; i++) {
		list.push(i);
	}

	document.writeln("<tr>");
	for (var i = 0; i < list.length; i++) {
		for (var j = 0; j< 12 && list.length != 0; j++){
			document.writeln("<td>" + list[0] + "</td>");
			list.shift();
		}
		document.writeln("</tr><tr>");
	}
	document.writeln("</table>");

}


// 	var d = new Day();
// 	var year = d.getFullYear();
// 	var list = new Array();

// 	for (var i = 1912; i < year; i++) {
// 		yearOrder.push(i);
// 	}

// 	document.writeln("<tr>");
// 	for (var i = 0; i < yearOrder; i++) {
// 		for (var j = 0; j< 12; j++){
// 			document.writeln("<td>" + yearOrder[0] "</td>");
// 			yearOrder.shift();
// 		}
// 		document.writeln("</tr><tr>");
// 	}
// }